<?php
session_start ();
require ("../../inc/common.php");
?>
<!DOCTYPE HTML>
<html lang="zh-cn">
<head>
<?php
$title = "acm算法讲解";
require BASE_INC . 'head.inc.php';
?>
<link href="<?php echo MAIN_DOMAIN;?>css/main.css" rel="stylesheet">
<link href="<?php echo MAIN_DOMAIN;?>acm/css/main.css" rel="stylesheet">

</head>
<script type="text/javascript">
var MAIN_DOMAIN = "<?php echo MAIN_DOMAIN;?>";
</script>

<body>

	<header>
		<div class="title">
			<a href="<?php echo MAIN_DOMAIN; ?>acm/info">acm算法讲解 </a>
			<div class="sub-title">
				<strong>作者:</strong> tiankonguse <strong>电子邮件:</strong> <a
					href="mailto:i@tiankonguse.com">i@tiankonguse.com</a> <strong>主页:</strong>
				<a href="http://tiankonguse.com/">http://tiankonguse.com/</a>
			</div>
		</div>

	</header>

	<section>
		<div class="container">
			<header style="text-align: center;"> Dijkstra 算法 </header>

			<div class="section">
				<div>Dijkstra( 迪杰斯特拉 ) 算法是典型的单源最短 路径算法,用于计算一个节点到其他所有节点
					的最短路径。主要特点是以起始点为中心向外 层层扩展,直到扩展到终点为止。 Dijkstra 算
					法是很有代表性的最短路径算法,在很多专业 课程中都作为基本内容有详细的介绍,如数据 结构,图论,运筹学等等。 Dijkstra
					一般的表 述通常有两种方式,一种用永久和临时标号方 式,一种是用 OPEN, CLOSE 表的方式,这里
					均采用永久和临时标号的方式。注意该算法要 求图中不存在负权回路。 ( 判负权回路用 ballmanford)</div>
			</div>

			<div class="section">
				<h2>算法描述</h2>
				<ul>
					<li>置集合 S={2,3,...n}, 数组 d(1)=0, d(i)=W1-&gt;i(1,i 之间存在边 ) or + 无穷大
						(1.i 之间不存在边 )</li>
					<li>在 S 中,令 d(j)=min{d(i),i 属于 S} ,令 S=S-{j} ,若 S 为空集则算法结束, 否则转 3</li>
					<li>对全部 i 属于 S, 如果存在边 j-&gt;i , 那么置 d(i)=min{d(i), d(j)+Wj-&gt;i}
						,转 2</li>
				</ul>
			</div>
			<div class="section">
				<h2>复杂度分析</h2>
				<ul>
					<li>Dijkstra 算法的时间复杂度为 O(n^2) 可以用堆优化 O(NlogN)</li>
					<li>空间复杂度取决于存储方式,邻接 矩阵为 O(n^2)</li>
				</ul>
			</div>
		</div>
	</section>

	<script src="<?php echo DOMAIN_JS;?>jquery.js"></script>
	<footer>
		<?php  require BASE_INC . 'footer.inc.php'; ?>
	</footer>
	<script src="<?php echo DOMAIN_JS;?>main.js"></script>
</body>
</html>

