<?php
session_start ();
require ("../../inc/common.php");
?>
<!DOCTYPE HTML>
<html lang="zh-cn">
<head>
<?php
$title = "acm算法讲解";
?>
<link href="<?php echo MAIN_DOMAIN;?>acm/css/main.css" rel="stylesheet">
</head>
<script type="text/javascript">
var MAIN_DOMAIN = "<?php echo MAIN_DOMAIN;?>";
</script>

<body>

	<section>
		<div class="container">
		\(log_a^n + log_a^m = log_a^{n*m}\)<br/>
		
		\(c^{2}=a^{2}+b^{2}\)
						<br/>
<br/>
\(c^{2}=a^{2}+b^{2}\)

\(\left(\begin{array}{cccc}
	1     &amp; 2 &amp; 3 &amp; 4 \\
	3     &amp; 1 &amp; 2 &amp; 4 
\end{array}\right)\)	



		</div>
	</section>
	
	<script src="<?php echo DOMAIN_mathjax;?>MathJax.js?config=TeX-AMS-MML_HTMLorMML" type="text/javascript"></script>
	
	
	
</body>
</html>

