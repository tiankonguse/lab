 <?php
	session_start ();
	require ("../../inc/common.php");
	?>
<!DOCTYPE HTML>
<html lang="zh-cn">
<head>
 <?php
	$title = "acm算法讲解";
	require BASE_INC . 'head.inc.php';
	?>
<link href="<?php echo MAIN_DOMAIN;?>css/main.css" rel="stylesheet">
<link href="<?php echo MAIN_DOMAIN;?>acm/css/main.css" rel="stylesheet">
</head>
<script type="text/javascript">
var MAIN_DOMAIN = "<?php echo MAIN_DOMAIN; ?>";
</script>

<body>
	<header>
		<div class="title">
			<a href="<?php echo MAIN_DOMAIN; ?>acm/info">acm算法讲解 </a>
		</div>
	</header>

	<section>
		<div class="container">
			<ul class="section">
				<li><a target="_blank"
					href="<?php echo MAIN_DOMAIN; ?>acm/info/LCA.php">最近公共祖先(LCA) </a></li>
				<li><a target="_blank"
					href="<?php echo MAIN_DOMAIN; ?>acm/info/LSP.php">最短路径 </a></li>
				<li><a href="<?php echo MAIN_DOMAIN; ?>acm/info/dijkstra.php">Dijkstra
						算法</a></li>
				<li>A* 算法</li>
				<li>SPFA 算法</li>
				<li><a href="<?php echo MAIN_DOMAIN; ?>acm/info/Bellman-Ford.php">Bellman-Ford
						算法</a></li>
				<li><a href="<?php echo MAIN_DOMAIN; ?>acm/info/floyd.php">Floyd-Warshall
						算法</a></li>
				<li>Johnson 算法</li>
				<li><a href="<?php echo MAIN_DOMAIN; ?>acm/info/CombinatorialMathematics.php">组合计数</a></li>
			</ul>

		</div>


	</section>

	<script src="<?php echo DOMAIN_JS;?>jquery.js"></script>
	<footer>
     <?php  require BASE_INC . 'footer.inc.php'; ?>
     </footer>
	<script src="<?php echo DOMAIN_JS;?>main.js"></script>
</body>
</html>




